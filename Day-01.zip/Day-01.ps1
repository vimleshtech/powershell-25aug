﻿

# comment line
# ctrl +   : increase the font size
# ctrl -   : decrease the font size
# F5  - to execute all command in current file 
# F8   - to execute selected command 

#Variable : is temp. memory where data/value/informatino can be stored 
#how to declare the variable

$n1 = 33   #here $n1 is variable and 33 is data or value , type is int 
$n2 = 33
$ip = "192.1.1.1"  #type is string 
$cname = "web.server.example.com"



#print or show in console
$n1 
Write-Host "ip is $ip"


##operation / expression 
$n = $n1 + $n2 
Write-Host "sum of two values $n"



##input type : default input data type is string
[int]$a = Read-Host "Enter data  "
[int]$b = Read-Host "Enter data  "

$c = $a + $b 
Write-Host "output is  $c"


###show which is greater 
if($a -gt $b){

    Write-Host "$a is greater no"
}
else
{
    Write-Host "$b is greater no"
}





###Loop : to repeat the task 
for($i=1; $i -lt 4; $i++){

        [int]$a = Read-Host "Enter data  "
        [int]$b = Read-Host "Enter data  "

        $c = $a + $b 
        Write-Host "output is  $c"




}



Get-ChildItem   'C:\Users\vkumar15\Documents\TestFolder'
Get-ChildItem   'C:\Users\vkumar15\Documents\TestFolder' -Recurse





